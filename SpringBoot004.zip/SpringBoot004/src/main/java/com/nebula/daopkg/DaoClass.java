package com.nebula.daopkg;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nebula.entitypkg.Employee;

@Repository
public interface DaoClass extends JpaRepository<Employee, Integer>{

	
}
