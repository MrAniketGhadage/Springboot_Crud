package com.nebula.entitypkg;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String name;
	private String address;
	private String monumber;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMonumber() {
		return monumber;
	}
	public void setMonumber(String monumber) {
		this.monumber = monumber;
	}
	
	public Employee() {
		super();
	}
	
	public Employee(Integer id, String name, String address, String monumber) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.monumber = monumber;
	}
	
	public Employee(String name, String address, String monumber) {
		super();
		this.name = name;
		this.address = address;
		this.monumber = monumber;
	}
	
	public Employee(String address, String monumber) {
		super();
		this.address = address;
		this.monumber = monumber;
	}
	
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", address=" + address + ", monumber=" + monumber + "]";
	}
	
	
	
	
}
