package com.nebula.servicepkg;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nebula.daopkg.DaoClass;
import com.nebula.entitypkg.Employee;

@Service
public class ServiceClass {
	
	@Autowired
	DaoClass daoClass;
	
//	To save the data
//	public Employee postData(Employee employee) {
//		Employee save = daoClass.save(employee);
//		return save;
//	}
	
	public Employee postData(Employee employee) {
		return daoClass.save(employee);	
	}
	
	
//	Getting Data from Database
	
//	public List<Employee> getAll(){
//		List<Employee> all = daoClass.findAll();
//		return all;
//	}
	public List<Employee> getAll(){
		return daoClass.findAll();
	}
	
//	Getting DataById
	
	public Optional<Employee> getById(Integer id) {
		Optional<Employee> byId = daoClass.findById(id);
		return byId;
	}
	
//	Update  data ById
	public String updateData(Employee employee) {
		Employee saveAndFlush = daoClass.saveAndFlush(employee);
		return "Data Updated SuccessFully..!!!";
	}
	
	
	
	
	
	
	
	
	
	

}
