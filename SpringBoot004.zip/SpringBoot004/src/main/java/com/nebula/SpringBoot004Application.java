package com.nebula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot004Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot004Application.class, args);
	}

}
